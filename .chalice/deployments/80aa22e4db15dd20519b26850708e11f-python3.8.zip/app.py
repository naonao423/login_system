from chalice import Chalice,NotFoundError,BadRequestError
from chalicelib import database

app = Chalice(app_name='calendar-backend')

@app.route('/events',cors=True)
def get_all_events():
    return  database.get_all_events()

#@app.route('/events/reload',methods=['POST'],cors=True)
#def reload_events():
#    return database.reload_event()
#return database.get_all_events()
