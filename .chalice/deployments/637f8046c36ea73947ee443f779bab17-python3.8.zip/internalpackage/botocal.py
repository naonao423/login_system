class Get_cal():

    def __init__(self):
        self.json = {"hello":"json"}

    def test(self):
        return self.json
