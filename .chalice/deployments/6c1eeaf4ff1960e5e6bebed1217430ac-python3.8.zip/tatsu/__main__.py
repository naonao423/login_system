# -*- coding: utf-8 -*-
from __future__ import generator_stop
import tatsu

if __name__ == '__main__':
    tatsu.main()
