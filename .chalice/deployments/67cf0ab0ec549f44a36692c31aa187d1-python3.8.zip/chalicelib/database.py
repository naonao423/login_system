import os
import boto3
from boto3.dynamodb.conditions import Key
import uuid
import json
import time
from internalpackage import botocal
import arrow,datetime

#ここでデータベースを作る必要がなくなったのでデータは無い

#DynamoDBへの接続を取得する。
def _get_database():
    endpoint = os.environ.get("DB_ENDPOINT")
    if endpoint:
        return boto3.resource("dynamodb",endpoint_url=endpoint)
        print("endpointあります！！")
    else:
        return boto3.resource("dynamodb")

#すべてのレコードを取得する
def load_all_events():
    #table = _get_database().Table(os.environ["DB_TABLE_NAME"])
    #response = table.scan()
    #return response['Items']

    #cwd = os.getcwd()
    #datapath = os.path.join(cwd,'data.json')
    #with open(datapath) as file:
    #    return json.load(file)
    return botocal.Get_cal().assign_to_dics()

def reload_event():
    start = time.time()
    table = _get_database().Table(os.environ["DB_TABLE_NAME"])
    response = table.scan()
    #ここのタイプはおそらくリスト
    exist_item_list = response["Items"]
    #これもおそらくリスト
    new_item_list = botocal.Get_cal().assign_to_dics()
    amount_of_already_exist = 0
    amount_of_change = 0
    check_exist = 0
    add_list = []
    for put_part in new_item_list:
        #書き込みたいファイルのuidを定義
        put_uid = put_part["uid"]
        for exist_part in exist_item_list:
            exist_uid = exist_part['uid']

            #データが存在するか
            if put_uid == exist_uid:
                amount_of_already_exist += 1
                check_exist = 1
            #存在しないなら追加
                
        if check_exist == 0:
            table.put_item(Item=put_part)
            add_list.append(put_part)
            amount_of_change +=1
        check_exist = 0        
    end = time.time()
    return add_list,len(new_item_list),amount_of_change,amount_of_already_exist,end-start

def get_all_events():
    print(_get_database())
    table = _get_database().Table(os.environ["DB_TABLE_NAME"])
    response = table.scan()
    return response['Items']
    
def get_summary_of_events(start,stop):
    start_time = str(arrow.get(start))
    stop_time = str(arrow.get(stop))
    print(start_time,stop_time)
    table = _get_database().Table(os.environ["DB_TABLE_NAME"])
    fe = Key('begin_time').between(start_time,stop_time);
    response = table.scan(
                        FilterExpression=fe
                                    )
    output_dic = response['Items']
    #sublist=["Nap","Programing","English","Study","Meditation","Stretch","英単語","Reading"]
    #sublistの設定をinitial_data.jsonから読みとる。
    subkey = Key('uid').eq("setting");
    sublist = table.scan(
            FilterExpression=subkey
            )
    sublist = sublist['Items'][0]["sub"]
    print(sublist)
    sublist = sublist.split(";")
    print(sublist)
    summary_output_list = []
    summary_dic_name = {}
    for subject in sublist:
        summary_dic = {"hour":0,"minute":0,"second":0}
        for part in output_dic:
            #settingは無視するようにする。
            if part["uid"] == "setting":
                pass
            else:
                if part['sub'] == "Programming":
                    name = "Programing"
                else:
                    name = part['sub']
                if name == subject:
                    (hour,minute,second) = part['duration'].split(":")
                    summary_dic['hour'] += int(hour)
                    summary_dic['minute'] += int(minute)
                    summary_dic['second'] += int(second)
                    if summary_dic['second'] >= 60:
                        summary_dic['second'] -=60
                        summary_dic['minute'] += 1
                    if summary_dic['minute'] >= 60:
                        summary_dic['minute'] -=60
                        summary_dic['hour'] += 1
            summary_dic_name[subject] = summary_dic
    #summary_output_list.append(summary_dic_name)
    #return summary_output_list
    return summary_dic_name
        
    
def get_datescale_of_events(start,stop):
    start_time = (arrow.get(start))
    stop_time = (arrow.get(stop))
    ident = int(str(start_time-stop_time).split(" ")[0])
    time_list = []
    if ident < 0:
        print('時間を一日ごとに分けます')
        k = 1
        while(k <=3):
            time_list.append(str(start_time))
            print(start_time)
            start_time = start_time.shift(days=1)
            if start_time == stop_time :
                k += 1
            elif k != 1:
                k += 1
    print(time_list)
    len_time_list = len(time_list)
    date_scale_dic = {}
    output_dic =[]
    for num in range(len_time_list-1):            
        table = _get_database().Table(os.environ["DB_TABLE_NAME"])
        fe = Key('begin_time').between(time_list[num],time_list[num+1]);
        response = table.scan(
                            FilterExpression=fe
                                        )
        output_dic = response['Items']
        #sublist=["Nap","Programing","English","Study","Meditation","Stretch","英単語","Reading"]
        #sublistの設定をinitial_data.jsonから読みとる。
        subkey = Key('uid').eq("setting");
        sublist = table.scan(
                FilterExpression=subkey
                )
        sublist = sublist['Items'][0]["sub"]
        sublist = sublist.split(";")
        summary_output_list = []
        summary_dic_name = {}
        for subject in sublist:
            summary_dic = {"minute":0}
            for part in output_dic:
                #settingは無視するようにする。
                if part["uid"] == "setting":
                    pass
                else:
                    if part['sub'] == "Programming":
                        name = "Programing"
                    else:
                        name = part['sub']
                    if name == subject:
                        (hour,minute,second) = part['duration'].split(":")
                        summary_dic['minute'] += int(hour)*60 + int(minute) + int(second)/60
            summary_dic_name[subject] = summary_dic
        date_scale_dic[time_list[num]] = summary_dic_name
    #summary_output_list.append(summary_dic_name)
    #return summary_output_list
    return date_scale_dic

#指定されたIDのレコードを取得する。
#def get_todo(todo_id):
#    table = _get_database().Table(os.environ["DB_TABLE_NAME"])
#    response = table.query(
#            KeyConditionExpression = Key('id').eq(todo_id)
#            )
#    items = response['Items']
#    return items[0] if items else None
#         
##Todoを作成する。
#def create_todo(todo):
#    #登録内容を作成する
#    item ={
#            'id':uuid.uuid4().hex,
#            'title':todo['title'],
#            'memo':todo['memo'],
#            'priority':todo['priority'],
#            'completed':False,
#            }
#    #登録内容をDynamoDBに登録する。
#    table = _get_database().Table(os.environ['DB_TABLE_NAME'])
#    table.put_item(Item=item)
#    return item
#           
##データを更新する
#def update_todo(todo_id,changes):
#    table = _get_database().Table(os.environ['DB_TABLE_NAME'])
#    #クエリを構築する(ここでは変更内容のみを保存している)
#    #list型で保存している
#    update_expression=[]
#    #辞書型で保存している
#    expression_attribute_values = {}
#    for key in ['title', 'memo', 'priority', 'completed']:
#        if key in changes:
#            update_expression.append(f"{key} = :{key[0:1]}")
#            #変化したものを変化した属性の頭文字をkeyとしてvalueに変更内容を格納する.
#            expression_attribute_values[f":{key[0:1]}"] = changes[key]
#    #こっちでtodo_idを選択してそのidに対して変更内容を適用している。
#    #DynamoDBのデータを更新する
#    result = table.update_item(
#            Key={
#                "id" : todo_id,
#                },
#            #更新したものを表示する変数
#            UpdateExpression='set '+ ','.join(update_expression),
#            ExpressionAttributeValues = expression_attribute_values,
#            ReturnValues='ALL_NEW'
#            )
#    return result['Attributes']
#
##todoを消す
#def delete_todo(todo_id):
#    table = _get_database().Table(os.environ['DB_TABLE_NAME'])
#    
#    #データを削除する
#    result = table.delete_item(
#            Key={
#                'id':todo_id,
#                },
#            ReturnValues='ALL_OLD'
#            )
#    return result['Attributes']




