# -*- coding: utf-8 -*-
from __future__ import generator_stop

from . import main

if __name__ == '__main__':
    main()
