import os
import boto3
from boto3.dynamodb.conditions import Key
import uuid
import json
from internalpackage import botocal

#ここでデータベースを作る必要がなくなったのでデータは無い

#DynamoDBへの接続を取得する。
#def _get_database():
#    endpoint = os.environ.get("DB_ENDPOINT")
#    if endpoint:
#        return boto3.resource("dynamodb",endpoint_url=endpoint)
#    else:
#        return boto3.resource("dynamodb")

#すべてのレコードを取得する
def get_all_events():
    #table = _get_database().Table(os.environ["DB_TABLE_NAME"])
    #response = table.scan()
    #return response['Items']

    #cwd = os.getcwd()
    #datapath = os.path.join(cwd,'data.json')
    #with open(datapath) as file:
    #    return json.load(file)
    return botocal.Get_cal().assign_to_dics()

#指定されたIDのレコードを取得する。
#def get_todo(todo_id):
#    table = _get_database().Table(os.environ["DB_TABLE_NAME"])
#    response = table.query(
#            KeyConditionExpression = Key('id').eq(todo_id)
#            )
#    items = response['Items']
#    return items[0] if items else None
#         
##Todoを作成する。
#def create_todo(todo):
#    #登録内容を作成する
#    item ={
#            'id':uuid.uuid4().hex,
#            'title':todo['title'],
#            'memo':todo['memo'],
#            'priority':todo['priority'],
#            'completed':False,
#            }
#    #登録内容をDynamoDBに登録する。
#    table = _get_database().Table(os.environ['DB_TABLE_NAME'])
#    table.put_item(Item=item)
#    return item
#           
##データを更新する
#def update_todo(todo_id,changes):
#    table = _get_database().Table(os.environ['DB_TABLE_NAME'])
#    #クエリを構築する(ここでは変更内容のみを保存している)
#    #list型で保存している
#    update_expression=[]
#    #辞書型で保存している
#    expression_attribute_values = {}
#    for key in ['title', 'memo', 'priority', 'completed']:
#        if key in changes:
#            update_expression.append(f"{key} = :{key[0:1]}")
#            #変化したものを変化した属性の頭文字をkeyとしてvalueに変更内容を格納する.
#            expression_attribute_values[f":{key[0:1]}"] = changes[key]
#    #こっちでtodo_idを選択してそのidに対して変更内容を適用している。
#    #DynamoDBのデータを更新する
#    result = table.update_item(
#            Key={
#                "id" : todo_id,
#                },
#            #更新したものを表示する変数
#            UpdateExpression='set '+ ','.join(update_expression),
#            ExpressionAttributeValues = expression_attribute_values,
#            ReturnValues='ALL_NEW'
#            )
#    return result['Attributes']
#
##todoを消す
#def delete_todo(todo_id):
#    table = _get_database().Table(os.environ['DB_TABLE_NAME'])
#    
#    #データを削除する
#    result = table.delete_item(
#            Key={
#                'id':todo_id,
#                },
#            ReturnValues='ALL_OLD'
#            )
#    return result['Attributes']




