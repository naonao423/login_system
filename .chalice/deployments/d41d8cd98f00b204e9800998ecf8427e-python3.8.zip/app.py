from chalice import Chalice,NotFoundError,BadRequestError
import chalicelib.database as database
import chalicelib.botocal as botocal

app = Chalice(app_name='calendar-backend')

@app.route('/events',cors=True)
def get_all_events():
    return  botocal.Get_cal().assign_to_dics()

#@app.route('/events/reload',methods=['POST'],cors=True)
#def reload_events():
#    return database.reload_event()
#return database.get_all_events()
