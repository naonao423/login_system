# -*- coding: utf-8 -*-
__toolname__ = 'TatSu'
__version__ = '5.5.0'
